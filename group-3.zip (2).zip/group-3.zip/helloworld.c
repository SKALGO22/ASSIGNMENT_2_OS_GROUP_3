#include <stdio.h>

int main(void){
    printf("Hello World!");
    printf("\n");
    return 0;
}
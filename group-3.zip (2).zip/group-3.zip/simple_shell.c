#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>

#define SIZE 100

int i = 0;
int status;
static int count = 0;
int background = 0;
char* copy;

char* cmd[SIZE];
pid_t pid_val[SIZE];
long long start_time[SIZE];
long long end_time[SIZE];
long long duration[SIZE];


long long current_time(){
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return (long long)tv.tv_sec*1000 + tv.tv_usec;
}

void exec_instr(char* command){
    if(command[0] == 'e'){ // echo command
        int j = 5;
        char string[SIZE];
        while(command[j] != '\0'){
            string[j-5] = command[j];
            j++;
        }
        string[j-5] = '\0';
        char * args[3] = {"/bin/echo",string, NULL};
        execv(args[0],args);
    } // ls /home command
    else if(command[0] == 'l' && command[1] == 's' && command[2] == ' ' && command[3] == '/' && command[4] == 'h'){
        char *home_dir = getenv("HOME");
        char * args[3] = {"/bin/ls",home_dir,NULL};
        execv(args[0],args);
    }// ls -l command
    else if(command[0] == 'l' && command[1] == 's' && command[2] == ' ' && command[3] == '-' && command[4] == 'l'){
        char *args[3] = {"/bin/ls","-l",NULL};
        execv(args[0],args);
    }// ls -R command
    else if(command[0] == 'l' && command[1] == 's' && command[2] == ' ' && command[3] == '-' && command[4] == 'R'){
        char * args[3] = {"/bin/ls","-R",NULL};
        execv(args[0],args);
    }// ls command
    else if(command[0] == 'l' && command[1] == 's'){
        char * args[2] = {"/bin/ls",NULL};
        execv(args[0],args);
    }// wc -l fib.c command
    else if(command[0] == 'w' && command[4] == 'l'){
        char * args[4] = {"wc","-l","fib.c",NULL};
        execv("/usr/bin/wc",args);
    }// wc -c fib.c command
    else if(command[0] == 'w' && command[4] == 'c'){
        char * args[4] = {"wc","-c","fib.c",NULL};
        execv("/usr/bin/wc",args);
    }// ./fib num command
    else if(command[0] == '.' && command[2] == 'f'){
        int j = 6;
        char string[SIZE];
        while(command[j]!='\0'){
            string[j-6] = command[j];
            j++;
        }
        string[j-6] = '\0';
        char * args[3] = {"./fib",string,NULL};
        execv(args[0],args);
        printf("\n");
        exit(0);
    }// ./helloworld
    else if(command[0] == '.' && command[2] == 'h'){
        char * args[2] = {"./helloworld",NULL};
        execv(args[0],args);
        printf("\n");
        exit(0);
    }// sort fib.c
    else if(command[0] == 's'){
        char * args[3] = {"sort","fib.c",NULL};
        execv("/usr/bin/sort",args);
    }// uniq file.txt
    else if(command[0] == 'u'){
        char * args[3] = {"uniq","file.txt",NULL};
        execv("/usr/bin/uniq",args);
    }// grep printf helloworld.c
    else if(command[0] == 'g'){
        char * args[4] = {"grep","printf","helloworld.c",NULL};
        execv("/usr/bin/grep",args);
    }// pwd command
    else if(command[0] == 'p'){
        char * args[2] = {"pwd",NULL};
        execv("/usr/bin/pwd",args);
    }// mkdir dir command
    else if(command[0] == 'm'){
        int j = 6;
        char string[SIZE];
        while(command[j]!='\0'){
            string[j-6] = command[j];
            j++;
        }
        string[j-6] = '\0';
        char * args[3] = {"mkdir",string,NULL};
        execv("/usr/bin/mkdir",args);
    }// touch file command
    else if(command[0] == 't'){
        int j = 6;
        char string[SIZE];
        while(command[j]!='\0'){
            string[j-6] = command[j];
            j++;
        }
        string[j-6] = '\0';
        char * args[3] = {"touch",string,NULL};
        execv("/usr/bin/touch",args);
    }
    // cat fib.c | wc -l
    else if(command[0] == 'c' && command[4] == 'f'){
        char * cat_args[3] = {"cat","fib.c",NULL};
        char * wc_args[3] = {"wc","-l",NULL};
        int fd[2];
        if(pipe(fd) == -1){ //Error checking for pipe
            perror("pipe");
            exit(EXIT_FAILURE);
        }
        int cat_pid = fork();
        if(cat_pid < 0){//Error checking for fork
            printf("Fork falied for cat");
            exit(EXIT_FAILURE);
        }
        else if(cat_pid == 0){
            close(fd[0]);
            dup2(fd[1],STDOUT_FILENO);
            close(fd[1]);
            execv("/bin/cat",cat_args);
        }
        else{
            close(fd[1]);
            dup2(fd[0],STDIN_FILENO);
            close(fd[0]);
            execv("/usr/bin/wc",wc_args);
        }
    }// cat helloworld.c | grep printf | wc -l
    else if(command[0] == 'c' && command[4] == 'h'){
        char * cat_args[3] = {"cat","fib.c",NULL};
        char * grep_args[4] = {"grep","printf","helloworld.c",NULL};
        char * wc_args[3] = {"wc","-l",NULL};
        int fd2[2];
        if(pipe(fd2) == -1){//Error checking for pipe
            perror("pipe");
            exit(EXIT_FAILURE);
        }
        int grep_pid = fork();
        if(grep_pid<0){//Error checking for fork
            printf("Fork failed for grep");
            exit(EXIT_FAILURE);
        }
        else if(grep_pid == 0){
            close(fd2[0]);
            dup2(fd2[1],STDOUT_FILENO);
            close(fd2[1]);
            int fd[2];
            if(pipe(fd) == -1){//Error checking for pipe
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            int cat_pid = fork();
            if(cat_pid < 0){//Error checking for fork
                printf("Fork failed for cat");
                exit(EXIT_FAILURE);
            }
            else if(cat_pid == 0){
                close(fd[0]);
                dup2(fd[1],STDOUT_FILENO);
                close(fd[1]);
                execv("/bin/cat",cat_args);
            } 
            else{
                close(fd[1]);
                dup2(fd[0],STDIN_FILENO);
                close(fd[0]);
                execv("/usr/bin/grep",grep_args);
            }
        }
        else{
            close(fd2[1]);
            dup2(fd2[0],STDIN_FILENO);
            close(fd2[0]);
            execv("/usr/bin/wc",wc_args);
        }
    }
}

int create_process_and_run(char* command){
    int status = fork();
    if(status<0){//Error checking for fork
        printf("Something bad happened");
        exit(0);
    }else if(status == 0){
        pid_val[i] = get_pid();
        exec_instr(command);
    }else{
        if(!background){
            int ret;
            int pid = wait(&ret); // waiting for the child process
            pid_val[i] = pid;
            if(WIFEXITED(ret)){
                printf("%d Exit = %d\n",pid,WEXITSTATUS(ret));
            }else{
                printf("I am the parent shell\n");
            }
        }
        else{
            printf("Background porcess inititated with pid %d\n",getpid());
            pid_val[i] = getpid();
            sleep(2); // waiting for the background process to get executed
        }
    }
    return 1;
}

int launch(char * command){
    int status;
    start_time[i] = current_time(); //before process
    status = create_process_and_run(command);
    end_time[i] = current_time(); //after process
    duration[i] = (-1*start_time[i] + end_time[i]);
    return status;
}

char * read_user_input(void){
    int c, k = 0;
    static char command[SIZE];
    while((c = getchar())!= '\n'){
        command[k] = c;
        k++;
    }
    command[k] = '\0';
    return command;
}

void display_metadata(){
    printf("\n");
    printf("Command  Start  End  Duration  pid\n");
    for(int num = 0;num<i; num++){
        printf("%s  %lld  %lld  %lld  %d\n",cmd[num],start_time[num],end_time[num],duration[num],pid_val[num]);
    }
}

void signal_handler(int sig_num){
    count ++;
    if(count>1){
        exit(0);
    }
    display_metadata();
    exit(0);
}

void shell_loop(){
    do{
        printf("sushantkumar@iiitd:~$ ");
        char * command = read_user_input();
        copy = malloc(SIZE);
        if (copy == NULL){ // checking malloc error
            fprintf(stderr,"malloc safe!\n");
            exit(0);
        }
        int j = 0;
        while(command[j]!='\0'){
            copy[j] = command[j];
            j++;
        }
        if(copy[j-1] == '&'){ //checking for background command
            copy[j-1] = '\0';
            background = 1;
        }
        else{
            copy[j] = '\0';
            background = 0;
            wait(NULL); 
        }
        cmd[i] = copy;
        if(copy[0] == 'h') // checking for history command
            for(int num = 0;num<=i;num++)
                printf("%s\n",cmd[num]);
        status = launch(command);
        i++;
        signal(SIGINT, signal_handler); // catching Ctrl+C interrupt
    }while(status);
}

int main(void){
    shell_loop();
    free(copy); // freeing malloc allocated heap memory
    return 0;
}
